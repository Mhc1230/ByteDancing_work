//
//  Passenger.h
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Orders : NSObject
@property(nonatomic,strong) NSDate _gooff;
@property(nonatomic,copy) Station *_startpoint;
@property(nonatomic,copy) Station *_destination;



@end


@interface Station : NSObject

@property(nonatomic,copy) NSString _province;
@property(nonatomic, copy) NSString _station;

@end

@interface Passenger : Person

// @property 属性
// 是否年满 18 岁
// 历史订单 （数组）
// 未出行订单 （数组）
@property(nonatomic,assign) bool _isAdult;
@property(nonatomic, copy) NSmutableArray *_HistoryOrders;
@property(nonatomic, copy) NSmutableArray *_UntravelledOrders;
// Function 方法
- (instancetype)initWith:(Person*)passenger;
-(void)creatPassengerWithisAdult:(bool)_isAdult HO:(NSmutableArray*)_HistoryOrders UO:(NSmutableArray*)_UntravelledOrders;
// 去订票
- (void)reserveWith:(Person*)passsenger SP:(Station*)sp DT:(Station*)dt Time:(NSDate)time;
// 去检票
- (void)checkWith:(Person*)passsenger SP:(Station*)sp DT:(Station*)dt Time:(NSDate)time;
@end

NS_ASSUME_NONNULL_END
