//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"


@implementation Orders

@end

@implementation Passenger
// Function 方法
//初始化
-(instancetype)initWith:(Person*)passenger{
    if(self=[super init]){
    [self creatPassengerWithisAdult:_isAdult HO:_HistoryOrders UO:_UntravelledOrders];
        }
      return self;
}
-(void)creatPassengerWithisAdult:(bool)_isAdult HO:(NSmutableArray*)_HistoryOrders UO:(NSmutableArray*)_UntravelledOrders{
    bool n=(Person.age>=18);
        self._isAdult=n;
        self._HistoryOrders=[[NSmutableArray alloc] init];
        self._UntravelledOrders=[[NSmutableArray alloc] init];
}
// 去订票
-(void)reserveWith:(Person*)passenger SP:(Station*)sp DT:(Station*)dt Time:(NSDate)time{
_ Order* od;
  od->_startpoint=sp;
  od->_destination=dt;
  od->_gooff=time;
  [passenger->_UntravelledOrders addObject:od];  //未出行数组元素增加
}
// 去检票
-(void)checkWith:(Person*)passsenger SP:(Station*)sp DT:(Station*)dt Time:(NSDate)time{
if(passenger->_UntravelledOrders != NULL){
    Order* od;
    od->_startpoint=sp;
    od->_destination=dt;
    od->_gooff=time;
    [passenger->_HistoryOrders addObject:Od];  //历史出行数组元素增加
    NSLog(@"check successfully");
    for(int i=0;i<sizeof(passenger->_UntravelledOrders);i++){  
        if(passenger->_UntravelledOrders[i]==od)
            break;
        else{
                NSLog(@"check wrong");}
}
    
    [passenger->_UntravelledOrders removeObjectAtIndex:i];
    }        // 为出行数组元素减少
}
@end
